from .rust_hello import *

__doc__ = rust_hello.__doc__
if hasattr(rust_hello, "__all__"):
    __all__ = rust_hello.__all__